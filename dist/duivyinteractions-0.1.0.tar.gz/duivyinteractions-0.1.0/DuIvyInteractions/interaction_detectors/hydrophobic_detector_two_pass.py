# -*- coding: utf-8 -*-
"""疏水相互作用检测器（两轮遍历 + 稀疏存储）。

判据：两个疏水碳原子之间距离在 0.5~4.0 Å。
参考：PLIP。

Pass1：KDTree 自查询发现近邻对 + 距离过滤（PBC 感知）
Pass2：从 InteractionSparse 重建索引 + 向量化计算（PBC 感知）

PBC：距离计算传 box（最小镜像约定），见 doc/pbc_design.md。
"""

import numpy as np
from typing import List, Tuple, Dict

from ..core.interfaces import InteractionDetectorTwoPass
from ..core.datas import Group, Interaction, InteractionSparse
from ..core.pbc import get_box


# PLIP 阈值
HYDROPH_DIST_MAX = 4.0  # Å，疏水原子间最大距离
HYDROPH_MIN_DIST = 0.5  # Å，最小距离


class HydrophobicDetectorTwoPass(InteractionDetectorTwoPass):
    """疏水相互作用检测器（两轮遍历 + 稀疏存储）。"""

    @property
    def name(self) -> str:
        return "hydrophobic"

    @property
    def required_group_types(self) -> List[str]:
        return ["hydrophobic"]

    @property
    def metric_names(self) -> List[str]:
        return ["distance"]

    # ==================== Pass1：KDTree 发现 ====================

    def run_pass1(self, groups: List[Group], trajectory,
                  tuple_filter=None) -> InteractionSparse:
        """执行 Pass1：KDTree 自查询发现近邻对。"""
        hydro_groups = [g for g in groups if g.group_type == "hydrophobic"]

        if not hydro_groups:
            return InteractionSparse(interaction_type=self.name, data={})

        # 构建原子索引数组
        self._atom_indices = np.array(
            [g.atoms[0].atom_global_idx for g in hydro_groups])

        sparse_data: Dict[Tuple[int, ...], dict] = {}

        for f, ts in enumerate(trajectory):
            pairs, distances = self._kdtree_discover(ts.positions,
                                                     get_box(ts))

            for i, j, dist in zip(pairs[0], pairs[1], distances):
                g1 = hydro_groups[i]
                g2 = hydro_groups[j]

                if tuple_filter is not None and not tuple_filter((g1, g2)):
                    continue

                group_ids = (g1.group_id, g2.group_id)

                if group_ids not in sparse_data:
                    sparse_data[group_ids] = {
                        "groups": (g1, g2),
                        "frames": [],
                        "metrics": {"distance": []}
                    }

                sparse_data[group_ids]["frames"].append(f)
                sparse_data[group_ids]["metrics"]["distance"].append(dist)

        # 疏水是原子级相互作用：每个原子对接触独立成立，不做同残基聚合

        return InteractionSparse(interaction_type=self.name, data=sparse_data)

    # ==================== Pass2：从 InteractionSparse 重建 ====================

    def _get_box(self, ts):
        """PBC：返回当前帧盒尺寸（None=无盒退化欧氏）。"""
        return get_box(ts)

    # ==================== compute_pair_metrics ====================

    def compute_pair_metrics(self, group_tuples, all_positions, box=None):
        """向量化计算距离（使用 _build_indices_from_sparse 缓存的索引）。

        box: 盒尺寸（MIC）；None = 欧氏距离（无 PBC）。
        """
        if not hasattr(self, '_pair_idx1'):
            raise RuntimeError(
                "compute_pair_metrics requires cached indices. "
                "Call _build_indices_from_sparse first via run_pass2.")
        from MDAnalysis.lib.distances import calc_bonds
        pos1 = all_positions[self._pair_idx1]
        pos2 = all_positions[self._pair_idx2]
        return {"distance": calc_bonds(pos1, pos2, box=box)}

    def apply_threshold(self, metrics):
        """0.5 < 距离 < 4.0。"""
        return (metrics["distance"] > HYDROPH_MIN_DIST) & \
               (metrics["distance"] < HYDROPH_DIST_MAX)

    # ==================== 内部辅助方法 ====================

    def _kdtree_discover(self, all_positions, box=None):
        """PBC 感知的自查询发现近邻对。返回 (pairs, distances)。

        box: 盒尺寸（MIC）；None = 欧氏距离（无 PBC）。
        """
        from MDAnalysis.lib.distances import self_capped_distance

        coords = all_positions[self._atom_indices]
        pairs, distances = self_capped_distance(
            coords, HYDROPH_DIST_MAX, min_cutoff=HYDROPH_MIN_DIST,
            box=box, method='pkdtree', return_distances=True)
        if len(pairs) == 0:
            return (np.array([]), np.array([])), np.array([])
        return (pairs[:, 0], pairs[:, 1]), distances

    def _build_indices_from_sparse(self, sparse: InteractionSparse):
        """从 InteractionSparse 重建原子索引数组（Pass2 用）。"""
        group_tuples = [entry["groups"] for entry in sparse.data.values()]
        self._pair_idx1 = np.array(
            [gt[0].atoms[0].atom_global_idx for gt in group_tuples])
        self._pair_idx2 = np.array(
            [gt[1].atoms[0].atom_global_idx for gt in group_tuples])
